import os
from docx import Document

def load_text_from_docx(file_path):
    """Extract text from DOCX file."""
    doc = Document(file_path)
    return "\n".join([p.text for p in doc.paragraphs if p.text.strip()])

def load_sop_documents(folder_path):
    """Load all SOP reference documents (txt or docx)."""
    docs = []
    for file in os.listdir(folder_path):
        if file.endswith(".txt") or file.endswith(".docx"):
            full_path = os.path.join(folder_path, file)
            if file.endswith(".docx"):
                text = load_text_from_docx(full_path)
            else:
                with open(full_path, "r", encoding="utf-8") as f:
                    text = f.read()
            docs.append({"name": file, "text": text})
    return docs
