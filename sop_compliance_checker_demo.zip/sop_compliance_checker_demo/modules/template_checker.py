from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_google_genai import ChatGoogleGenerativeAI

def check_template_compliance(document_text: str, template_text: str, api_key: str, model: str):
    """
    Compare a document's structure against the SOP template using Google Gemini.
    Returns a compliance assessment report.
    """
    # Initialize LLM (Gemini)
    llm = ChatGoogleGenerativeAI(model=model, google_api_key=api_key)

    # Define prompt for structure-based compliance
    prompt = PromptTemplate.from_template("""
    You are an expert SOP auditor.
    Compare the following document structure against the standard SOP template.

    Template Structure:
    {template}

    Submitted Document:
    {document}

    Identify:
    1. Missing or misordered sections
    2. Formatting or numbering deviations
    3. Overall template compliance (percentage)

    Respond in JSON with fields:
    {{
        "missing_sections": [...],
        "format_issues": [...],
        "compliance_score": "<0–100>",
        "summary": "<short summary>"
    }}
    """)

    # Build runnable chain
    chain = prompt | llm | StrOutputParser()

    # Run the chain
    response = chain.invoke({"template": template_text, "document": document_text})
    return response
