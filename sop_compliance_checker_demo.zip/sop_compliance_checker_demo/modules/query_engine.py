# modules/query_engine.py

from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnableMap

# LLM providers
from langchain_google_genai import ChatGoogleGenerativeAI


from config import settings


def create_vectorstore(persist_dir="./chroma_data"):
    """Create or load a Chroma vectorstore using open-source embeddings."""
    embedding_model = HuggingFaceEmbeddings(model_name=settings.EMBEDDING_MODEL)
    vectorstore = Chroma(
        persist_directory=persist_dir,
        embedding_function=embedding_model
    )
    return vectorstore


def create_retriever(vectorstore):
    """Create retriever from existing Chroma vectorstore."""
    return vectorstore.as_retriever(search_kwargs={"k": 3})


def create_rag_chain(retriever):
    """Create a RAG chain that uses whichever LLM is configured."""
    llm = ChatGoogleGenerativeAI(
            model=settings.GOOGLE_MODEL,
            google_api_key=settings.GOOGLE_API_KEY
        )

    prompt = PromptTemplate.from_template("""
    You are an SOP compliance expert. Use the context below to assess document compliance.
    
    Context:
    {context}

    Question:
    {question}
    """)

    def combine_docs(docs):
        return "\n\n".join([d.page_content for d in docs])

    chain = (
        RunnableMap({
            "context": retriever | combine_docs,
            "question": lambda x: x["question"],
        })
        | prompt
        | llm
        | StrOutputParser()
    )
    return chain


def query_rag(chain, question):
    """
    Queries the RAG chain and returns the result.
    Ensures input to embeddings is always a string.
    """
    if isinstance(question, dict):
        # If question is dict like {"question": "..."} extract the text
        question_text = question.get("question", "")
    elif not isinstance(question, str):
        # If some other object, convert to string safely
        question_text = str(question)
    else:
        question_text = question

    try:
        result = chain.invoke({"question": question_text})
        return result
    except Exception as e:
        import traceback
        traceback.print_exc()
        return {"error": str(e), "question": question_text}
