from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings

def build_vectorstore(sop_docs, persist_dir, model_name):
    """Build and persist a ChromaDB vectorstore."""
    texts = [d["text"] for d in sop_docs]
    metadatas = [{"source": d["name"]} for d in sop_docs]

    embedding = HuggingFaceEmbeddings(model_name=model_name)
    vectorstore = Chroma.from_texts(
        texts=texts,
        embedding=embedding,
        metadatas=metadatas,
        persist_directory=persist_dir
    )
    vectorstore.persist()
    return vectorstore
