
from modules.query_engine import create_vectorstore, create_retriever, create_rag_chain, query_rag

def check_content_compliance(document_text, vectorstore, api_key, model):
    # Create vectorstore (only once)
    #vectorstore = create_vectorstore("./sop_reference/chroma_data")

    # Create retriever
    retriever = create_retriever(vectorstore)

    # Create RAG chain
    chain = create_rag_chain(retriever)

    # Query compliance
    query = f"Check if the following document is compliant with the SOP and template:\n{document_text}"
    return query_rag(chain, query)
