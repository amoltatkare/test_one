import json
from datetime import datetime
import os

def generate_report(doc_name, template_result, content_result, output_path):
    """Save compliance results as JSON file."""
    report = {
        "document": doc_name,
        "timestamp": datetime.now().isoformat(),
        "template_compliance": template_result,
        "content_compliance": content_result
    }

    os.makedirs(output_path, exist_ok=True)
    file_path = os.path.join(output_path, f"report_{doc_name.replace('.docx', '')}.json")
    with open(file_path, "w") as f:
        json.dump(report, f, indent=4)
    return file_path
