python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt



### To start ChromaDB

export GOOGLE_API_KEY="AIzaSyAJawSImDKLhtv4dMqNFdt1hpmUFcVpbKQ"
chroma run --host 0.0.0.0 --port 8000 --path ./chroma_data 


### For PDF Example set 
export CHROMA_HOST = "localhost"
export CHROMA_PORT = "8000"
export CHROMA_COLLECTION_NAME = "reports"



pip install streamlit langchain langchain-core langchain-community \
             langchain-google-genai langchain-openai langchain-anthropic \
             sentence-transformers chromadb python-docx