from docx import Document
import os

os.makedirs("test_documents", exist_ok=True)


# ----------------------------------------------------------------------
# 1. FULLY COMPLIANT DOCUMENT
# ----------------------------------------------------------------------
def create_fully_compliant_doc():
    doc = Document()
    doc.add_heading("Website Testing SOP – E-Commerce Project", 0)

    # Metadata
    doc.add_paragraph("Version: 1.0")
    doc.add_paragraph("Prepared By: QA Engineer")
    doc.add_paragraph("Reviewed By: QA Lead")
    doc.add_paragraph("Approved By: Project Manager")
    doc.add_paragraph("Date: 2025-11-01")

    # Purpose
    doc.add_heading("1. Purpose", level=1)
    doc.add_paragraph(
        "The purpose of this SOP is to define a consistent and repeatable website testing process "
        "that ensures quality assurance, defect prevention, and release readiness for the e-commerce platform."
    )

    # Scope
    doc.add_heading("2. Scope", level=1)
    doc.add_paragraph(
        "This SOP applies to all QA activities for web, mobile, and tablet platforms. "
        "It excludes backend API and database load testing."
    )

    # Responsibilities
    doc.add_heading("3. Responsibilities", level=1)
    table = doc.add_table(rows=1, cols=2)
    hdr = table.rows[0].cells
    hdr[0].text = "Role"
    hdr[1].text = "Responsibility"
    roles = [
        ("QA Engineer", "Execute test cases, log defects, perform regression testing."),
        ("QA Lead", "Review test cases, approve test plan, ensure traceability."),
        ("Developer", "Resolve defects and support test verification."),
        ("Project Manager", "Oversee QA process and ensure timely sign-off.")
    ]
    for r, resp in roles:
        row = table.add_row().cells
        row[0].text = r
        row[1].text = resp

    # Pre-requisites
    doc.add_heading("4. Pre-requisites", level=1)
    items = [
        "Test environment must be accessible and stable.",
        "QA credentials created for all modules.",
        "Baseline test data loaded.",
        "Test management tools configured."
    ]
    for i, t in enumerate(items, start=1):
        doc.add_paragraph(f"{i}. {t}")

    # Types of Testing
    doc.add_heading("5. Types of Testing", level=1)
    tests = {
        "5.1 Functional Testing": "Verify feature behavior matches requirements using Selenium scripts.",
        "5.2 UI/UX Testing": "Check design alignment, colors, fonts, spacing, and interaction consistency.",
        "5.3 Compatibility Testing": "Ensure site works across Chrome, Firefox, Safari, Edge, and mobile browsers.",
        "5.4 Performance Testing": "Measure load times (<3s) and server response using JMeter.",
        "5.5 Security Testing": "Perform SQL injection and XSS tests using OWASP ZAP.",
        "5.6 Regression Testing": "Automate core flows with Playwright; rerun on every release.",
        "5.7 Accessibility Testing": "Ensure compliance with WCAG 2.1 AA using Axe DevTools."
    }
    for k, v in tests.items():
        doc.add_heading(k, level=2)
        doc.add_paragraph(v)

    # Test Execution Process
    doc.add_heading("6. Test Execution Process", level=1)
    steps = [
        "Review requirements and design test cases.",
        "Conduct smoke testing.",
        "Execute functional and regression suites.",
        "Log defects in Jira and assign to developers.",
        "Retest after fixes.",
        "Prepare daily QA report and TSR."
    ]
    for i, s in enumerate(steps, start=1):
        doc.add_paragraph(f"{i}. {s}")

    # Reporting and Metrics
    doc.add_heading("7. Reporting and Metrics", level=1)
    doc.add_paragraph(
        "QA Lead prepares a Daily QA Report and Test Summary Report (TSR). "
        "Metrics include Test Coverage %, Defect Density, and Automation Coverage %."
    )

    # Approval and Sign-Off
    doc.add_heading("8. Approval and Sign-Off", level=1)
    doc.add_paragraph(
        "QA Lead, Developer Lead, and Project Manager must sign off the test completion "
        "before production deployment."
    )

    # Document Control
    doc.add_heading("9. Document Control", level=1)
    t = doc.add_table(rows=2, cols=4)
    hdr = t.rows[0].cells
    hdr[0].text = "Version"
    hdr[1].text = "Date"
    hdr[2].text = "Description"
    hdr[3].text = "Author"
    row = t.rows[1].cells
    row[0].text = "1.0"
    row[1].text = "2025-11-01"
    row[2].text = "Initial release"
    row[3].text = "QA Engineer"
    doc.add_paragraph("Review cycle: Every 6 months.")

    # Appendix
    doc.add_heading("Appendix A – Test Case Template", level=1)
    doc.add_paragraph("Columns: Test ID, Description, Steps, Expected Result, Actual Result, Status")

    doc.save("data/documents_to_check/ECommerce_WebsiteTesting_SOP_v1.0.docx")


# ----------------------------------------------------------------------
# 2. PARTIALLY COMPLIANT DOCUMENT
# ----------------------------------------------------------------------
def create_partially_compliant_doc():
    doc = Document()
    doc.add_heading("Website Testing SOP – Partial Version", 0)
    doc.add_paragraph("Version: 0.8")
    doc.add_paragraph("Prepared By: QA Engineer")

    doc.add_heading("1. Purpose", level=1)
    doc.add_paragraph("To describe testing approach for the web application.")

    doc.add_heading("2. Scope", level=1)
    doc.add_paragraph("Applies to desktop and mobile platforms only.")

    doc.add_heading("3. Responsibilities", level=1)
    doc.add_paragraph("QA Engineer: Execute tests. Developer: Fix issues.")

    doc.add_heading("4. Pre-requisites", level=1)
    doc.add_paragraph("Test environment and data must be ready.")

    doc.add_heading("5. Types of Testing", level=1)
    doc.add_paragraph("Includes Functional, UI/UX, and Performance testing.")
    doc.add_paragraph("Security and Accessibility testing not included.")

    doc.add_heading("6. Test Execution Process", level=1)
    doc.add_paragraph("1. Execute test cases.\n2. Log defects.\n3. Re-test.")

    doc.add_heading("7. Reporting and Metrics", level=1)
    doc.add_paragraph("Daily summary sent via email.")

    # Missing Approval and Document Control sections

    doc.save("data/documents_to_check/ECommerce_WebsiteTesting_SOP_v0.8.docx")


# ----------------------------------------------------------------------
# 3. NON-COMPLIANT DOCUMENT
# ----------------------------------------------------------------------
def create_non_compliant_doc():
    doc = Document()
    doc.add_heading("Quick Website Testing Guide", 0)
    doc.add_paragraph(
        "Hey team! Here’s a quick note on how we test stuff. No strict format — just do functional tests and see if things look ok."
    )
    doc.add_paragraph(
        "Steps:\n1. Open the site\n2. Click around\n3. Report issues if any\n"
        "No need for reports, just ping on Slack. Cheers!"
    )
    doc.save("data/documents_to_check/Quick_Website_Testing_Guide.docx")


# ----------------------------------------------------------------------
# EXECUTE ALL
# ----------------------------------------------------------------------
create_fully_compliant_doc()
create_partially_compliant_doc()
create_non_compliant_doc()

print("✅ All sample SOP documents generated under 'test_documents/'")
