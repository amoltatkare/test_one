from docx import Document
import os

os.makedirs("sop_reference", exist_ok=True)

doc = Document()
doc.add_heading("Website Testing Standard Operating Procedure (SOP)", level=1)
doc.add_paragraph("Version: 1.0")
doc.add_paragraph("Prepared By: [Author Name]")
doc.add_paragraph("Reviewed By: [Reviewer Name]")
doc.add_paragraph("Approved By: [Approver Name]")
doc.add_paragraph("Date: [DD-MM-YYYY]")
doc.add_paragraph()

sections = {
    "1. Purpose": """This document defines the standardized process for testing all websites ...""",
    "2. Scope": """This SOP applies to all internal and client-facing websites built or maintained ...""",
    "3. Responsibilities": """QA Engineer, QA Lead, Developer, and Project Manager roles ...""",
    "4. Pre-requisites": """Ensure staging deployment, test data readiness, and tool setup before testing.""",
    "5. Types of Testing": """Covers Functional, UI/UX, Compatibility, Performance, Security, Regression, and Accessibility testing.""",
    "6. Test Execution Process": """Review test plan, execute cases, log defects, retest, and track progress.""",
    "7. Reporting and Metrics": """Daily QA reports, Test Summary Reports, KPIs like coverage, leakage, and automation rate.""",
    "8. Approval and Sign-Off": """All stakeholders must approve before go-live readiness declaration.""",
    "9. Document Control": """Maintain version history and ensure 6-monthly review.""",
    "Appendix": """Contains templates for Test Cases, Defect Reports, and QA Checklists."""
}

for heading, content in sections.items():
    doc.add_heading(heading, level=2)
    doc.add_paragraph(content)

doc.save("sop_reference/sop_template.docx")
print("✅ sop_reference/sop_template.docx created successfully.")
