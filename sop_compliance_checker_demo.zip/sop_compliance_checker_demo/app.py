import streamlit as st
import tempfile
import os

from config.settings import *
from modules.doc_loader import load_text_from_docx, load_sop_documents
from modules.vectorstore_builder import build_vectorstore
from modules.template_checker import check_template_compliance
from modules.content_checker import check_content_compliance
from modules.report_generator import generate_report


# --- Streamlit Page Setup ---
st.set_page_config(page_title="SOP Compliance Checker", layout="wide")
st.title("📋 SOP Compliance Checker")
st.write("Use this app to verify if your document follows the SOP template and policy guidelines.")


# --- Sidebar Configuration ---
with st.sidebar:
    st.header("⚙️ Configuration")
    st.markdown("**Google API Key:** must be set as environment variable `GOOGLE_API_KEY` before running.")
    if st.button("🔁 Rebuild SOP Knowledge Base"):
        st.info("Building vectorstore from SOP reference documents...")
        sop_docs = load_sop_documents("data/sop_reference")
        vectorstore = build_vectorstore(sop_docs, CHROMA_PATH, EMBEDDING_MODEL)
        st.success("✅ SOP Knowledge Base rebuilt successfully!")


# --- File Upload ---
uploaded_file = st.file_uploader("Upload a document for compliance check (.docx)", type=["docx"])

if uploaded_file:
    with tempfile.NamedTemporaryFile(delete=False, suffix=".docx") as tmp:
        tmp.write(uploaded_file.getbuffer())
        document_path = tmp.name

    st.success(f"📄 Uploaded file: {uploaded_file.name}")

    # Load SOP reference docs
    sop_docs = load_sop_documents("data/sop_reference")
    if not sop_docs:
        st.error("No SOP reference found in `data/sop_reference/`. Please add at least one SOP file.")
        st.stop()

    template_text = sop_docs[0]["text"]

    # Load or build Chroma vectorstore
    if not os.path.exists(CHROMA_PATH):
        st.info("Creating SOP knowledge base...")
        vectorstore = build_vectorstore(sop_docs, CHROMA_PATH, EMBEDDING_MODEL)
    else:
        from langchain_community.vectorstores import Chroma
        from langchain_community.embeddings import HuggingFaceEmbeddings
        vectorstore = Chroma(
            persist_directory=CHROMA_PATH,
            embedding_function=HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)
        )

    # Extract text
    document_text = load_text_from_docx(document_path)

    if st.button("🚀 Run Compliance Check"):
        st.write("Running analysis... this may take a minute ⏳")

        with st.spinner("Checking template compliance..."):
            template_result = check_template_compliance(template_text, document_text, GOOGLE_API_KEY, GOOGLE_MODEL)
        st.subheader("📑 Template Compliance Result")
        st.write(template_result)

        with st.spinner("Checking content compliance..."):
            content_result = check_content_compliance(document_text, vectorstore, GOOGLE_API_KEY, GOOGLE_MODEL)
        st.subheader("🧠 Content Compliance Result")
        st.write(content_result)

        # Save report
        report_dir = "outputs/compliance_reports"
        os.makedirs(report_dir, exist_ok=True)
        report_path = generate_report(uploaded_file.name, template_result, content_result, report_dir)

        st.success("✅ Compliance Check Completed Successfully!")
        with open(report_path, "r") as f:
            st.download_button(
                label="📥 Download JSON Report",
                data=f.read(),
                file_name=os.path.basename(report_path),
                mime="application/json"
            )
