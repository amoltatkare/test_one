import os

LLM_PROVIDER = "google"

# ---- API & Model Config ----
GOOGLE_API_KEY = ""
GOOGLE_MODEL = "gemini-2.5-flash"

# OpenAI
OPENAI_API_KEY = "sk-proj-"
OPENAI_MODEL = "gpt-4o-mini"

# Embedding (open-source, no key required)
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

# ---- Paths ----
CHROMA_PATH = "./chroma_db"
